#include <Bela.h>
#include <libraries/AudioFile/AudioFile.h>
#include <libraries/Convolver/Convolver.h>
#include <libraries/Scope/Scope.h>
#include <libraries/math_neon/math_neon.h>
#include <libraries/Gui/Gui.h>
#include <libraries/GuiController/GuiController.h>
#include <string>
#include <vector>
#include "MonoFilePlayer.h"
#include "DirectConvolver.h"
#include "FFTConvolver.h"
#include "ZLConvolver.h"
#include <libraries/OnePole/OnePole.h>
#include <chrono>

// globals for timing
//std::chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();
//std::chrono::steady_clock::time_point end = std::chrono::steady_clock::now();

int gReadPtr; // Position of last read sample from file
std::vector<float> data;

//add convolvers until you have as many as you have IRs
ZLConvolver zlConvolverA,
	zlConvolverB,
	zlConvolverC,
	zlConvolverD,
	zlConvolverE;


//add the IR files here
const std::string gIrFile3 = "1st100IR.wav";
const std::string gIrFile5 = "117IR.wav";
const std::string gIrFile1 = "136IR.wav";
const std::string gIrFile2 = "083IR.wav";
const std::string gIrFile4 = "154IR.wav";


	
	
//the microphone input	
const bool gProcessInput = true; // set to true to process the live input instead
const unsigned int gInputChannel = 0; // which channel to process in that case

//circular buffer and read pointer
std::vector<float> gDelayBuffer;
unsigned int gWritePointer = 0;
unsigned int gReadPointer = 0;


// Browser-based GUI to adjust parameters (we testing this for a single slider)
Gui gGui;
GuiController gGuiController;

unsigned int gRoomSlider;
unsigned int gDelaySlider;
unsigned int gMaxBlocksSlider;
unsigned int gSparsitySlider;


// global variables that track slider states
int gRoom = 0;
bool gRandom = 0;
int gKernelSize = 0;
OnePole input1Filter;
OnePole input2Filter;
int gCount = 0;
float gInterval = 1;


unsigned int gWetSlider;


bool setup(BelaContext *context, void *userData)
{
	//allocate circular buffer
	gDelayBuffer.resize(0.3 * context->audioSampleRate);
	
	//Lowpass filter
	input1Filter.setup(1, context->audioSampleRate); // 1 is the filter's cutoff frequency
	input2Filter.setup(1, context->audioSampleRate);
	// Set up the GUI
	gGui.setup(context->projectName);

	// and attach to it
	gGuiController.setup(&gGui, "Controls");

	// Arguments: name, default value, minimum, maximum, increment
	// store the return value to read from the slider later on
	//gGuiController.addSlider("name of slider", default value, lowest, highest, increment);
	gMaxBlocksSlider = gGuiController.addSlider("Max blocks", 30.0, 0.0, 30.0, 1.0);
	gSparsitySlider = gGuiController.addSlider("Sparsity (%)", 0.0, 0.0, 1.0, 0.1);
	gWetSlider = gGuiController.addSlider("Wet", 0.03, 0.0, 0.1, 0.01);
	
	zlConvolverA.setup(context->audioFrames, context->audioSampleRate, gIrFile1, false, 0);
	zlConvolverB.setup(context->audioFrames, context->audioSampleRate, gIrFile2, false, 0);
	zlConvolverC.setup(context->audioFrames, context->audioSampleRate, gIrFile3, false, 0);
	zlConvolverD.setup(context->audioFrames, context->audioSampleRate, gIrFile4, false, 0);
	zlConvolverE.setup(context->audioFrames, context->audioSampleRate, gIrFile5, false, 0);
	
	return true;
}


void render(BelaContext *context, void *userData)
{
	
	// Access the sliders specifying the index we obtained when creating then
	int maxBlocks = (int)gGuiController.getSliderValue(gMaxBlocksSlider);
	float sparsity = gGuiController.getSliderValue(gSparsitySlider);
	
	float inBuf[context->audioFrames]; // the buffer to be processed by the convolver
	for(unsigned int n = 0; n < context->audioFrames; n++) {
		float in = 0;
		
		if(gProcessInput) {
			in = audioRead(context, n, gInputChannel);
		}
		
		inBuf[n] = in;
	}
		
	float outBuf[context->audioFrames];


	for (unsigned int n = 0; n < context->audioFrames; n++)	
	{	
		// Declare ADC inputs from potentiometers
		float input0 = analogRead(context, n/2, 0); 
		float input1 = analogRead(context, n/2, 1);
		input1 = input1Filter.process(input1);
		float input2 = analogRead(context, n/2, 2);
		input2 = input2Filter.process(input2);
		
		// Map ADC inputs to useful value range based on usage
		float amplitudeDB = map(input0, 0, 3.4 / 4.096, -40, -6);
		float delay = map(input1, 0, 3.4 / 4.096, 0.0, 0.19);
		float room = map(input2, 0, 3.4 / 4.096, 0, 4.9);
		
		// Further value adjustment
		float dry = powf(10.0, amplitudeDB / 20); //convert dB to linear amplitude
		
		int delayInSamples = delay * context->audioSampleRate;
		gReadPointer = (gWritePointer - delayInSamples + gDelayBuffer.size()) % gDelayBuffer.size();
		
		
		float in = inBuf[n];
		float out = outBuf[n];
		
		// ... convolve it ...
		switch ((int)room)
		{
		case 0: //IR1
			out = zlConvolverA.process(in, 1.0, 1.0, maxBlocks, sparsity);
			break;
		case 1: //IR2
			out = zlConvolverB.process(in, 1.0, 1.0, maxBlocks, sparsity);
			break;
		case 2: //IR3
			out = zlConvolverC.process(in, 1.0, 1.0, maxBlocks, sparsity);
			break;
		 case 3: //IR4
		 	out = zlConvolverD.process(in, 1.0, 1.0, maxBlocks, sparsity);
			break;
		case 4: //IR5
		 	out = zlConvolverE.process(in, 1.0, 1.0, maxBlocks, sparsity);
			break;
		}	
	
		float wet = gGuiController.getSliderValue(gWetSlider);
		
		//this is the dry signal. we dont want to circular buffer this ever as
		//we have outBuf which is the convolved signal which we are delaying.
		in = in * dry;
		
		//Overwrite the buffer at the write pointer
		//Do this first so we can have the read and write pointers be equal
		gDelayBuffer[gWritePointer] = out;
		
		//read output from write pointer (oldest sample)
		float outDelay = gDelayBuffer[gReadPointer];
		
		//increment and wrap both pointers
		gWritePointer++;
		if(gWritePointer >= gDelayBuffer.size())
			gWritePointer = 0;
		gReadPointer++;
		if(gReadPointer >= gDelayBuffer.size())
			gReadPointer = 0;
			
		outDelay = outDelay * wet;
		
		for(unsigned int channel = 0; channel < context->audioOutChannels; ++channel)
			audioWrite(context, n, channel, outDelay + in);
			
		// // Add this back in when you want their results.
		// // Increment a counter on every frame
		// gCount++;
		// 	if(gCount % (int)(context->audioSampleRate*gInterval) == 0) {
		// 		rt_printf("Delay: %f\n", delay);
		// 		rt_printf("Dry Vol: %f\n", dry);
		// 		rt_printf("Int Room Value: %i\n", (int)room);
		// 		gCount = 0;
		// 	}
	
	}
}
void cleanup(BelaContext *context, void *userData)
{
}



